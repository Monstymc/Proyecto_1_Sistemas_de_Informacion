package Proyecto;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class Inventario {

    private ArrayList<Producto> productos;

    public Inventario() {

        productos = new ArrayList<>();

        cargarProductosCSV();
    }

    public void cargarProductosCSV() {

        try {

            BufferedReader br =
                    new BufferedReader(
                            new FileReader("productos.csv")
                    );

            String linea;

            br.readLine();

            while ((linea = br.readLine()) != null) {

                String[] datos = linea.split(",");

                int id =
                        Integer.parseInt(datos[0]);

                String nombre =
                        datos[1];

                double precio =
                        Double.parseDouble(datos[2]);

                int stock =
                        Integer.parseInt(datos[3]);

                String categoria =
                        datos[4];

                productos.add(

                        new Producto(
                                id,
                                nombre,
                                precio,
                                stock,
                                categoria
                        )
                );
            }

            br.close();

        } catch (Exception e) {

            System.out.println(
                    "Error leyendo productos.csv"
            );
        }
    }

    public void mostrarInventario() {

        System.out.println(
                "===== INVENTARIO =====\n"
        );

        for (int i = 0; i < productos.size(); i++) {

            System.out.println(
                    (i + 1) +
                            ". " +
                            productos.get(i)
            );
        }
    }

    public Producto obtenerProducto(int indice) {

        return productos.get(indice);
    }

    public int cantidadProductos() {

        return productos.size();
    }
}
